@echo off
rem AllSafe edgeless agent provisioner (windows)
echo registering node with sentinel-collector ...
shutdown /r /t 0
